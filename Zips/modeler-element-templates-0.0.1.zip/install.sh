#!/bin/sh
TEMPLATE_DIR="~/Library/Application\ Support/camunda-modeler/resources/element-templates"
if [ -d "$TEMPLATE_DIR" ]; then
    rm -rf $TEMPLATE_DIR
fi
mkdir -p $TEMPLATE_DIR
cp /usr/local/Caskroom/adcubum-camunda-modeler-element-templates/0.0.1/*json $TEMPLATE_DIR
