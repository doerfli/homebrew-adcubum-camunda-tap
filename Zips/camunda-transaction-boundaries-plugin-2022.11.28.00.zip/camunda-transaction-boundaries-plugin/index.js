'use strict';

module.exports = {
  name: 'Transaction Boundaries',
  menu: './menu/menu.js',
  script: './client/client-bundle.js',
  style: './style/style.css'
};
