import {
  registerPlatformBpmnJSPlugin
} from 'camunda-modeler-plugin-helpers';

import module from './module';

registerPlatformBpmnJSPlugin(module);
