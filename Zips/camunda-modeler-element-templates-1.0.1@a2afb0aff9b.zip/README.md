# Installation instructions

Do not forget to install this template for linux and windows users (and check if it is still working for mac).

Download the latest archive:
  https://git.adcubum.com/rest/api/latest/projects/SYR/repos/camunda-modeler-element-templates/archive?format=zip

## Homebrew package update instructions

1. Checkout the homebrew tap https://github.com/doerfli/homebrew-adcubum-camunda-tap 
1. Create a tag in the repository (`git tag m.n.p`) and push it to the server
1. Download the Zip for the tag (e.g. https://git.adcubum.com/rest/api/latest/projects/SYR/repos/camunda-modeler-element-templates/archive?at=refs%2Ftags%2F1.0.0&format=zip) and store it in the Zips subdirectory of the tap
1. Edit the cask file in the tap at `Casks/adcubum-element-templates.rb` 
  1. Update field `version`
  1. Update field `sha256` with the hash of the zip (`sha256sum Zips/camunda-modeler-element-templates-1.0.0@8402ff3e40f.zip`)
  1. Update field `url` with the new filename
  1. See example commit https://github.com/doerfli/homebrew-adcubum-camunda-tap/commit/42e7fea30d0181f3af1db29b17d7c9756e41c4eb 
1. Commit the update and push it to github
1. Updated cask is ready to be installed (brew install doerfli/adcubum-camunda-tap/adcubum-element-templates) or updated (brew upgrade doerfli/adcubum-camunda-tap/adcubum-element-templates) 
