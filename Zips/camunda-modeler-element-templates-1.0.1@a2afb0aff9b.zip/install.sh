#!/bin/bash
SOURCE_DIR=`dirname "$0"`
TEMPLATE_DIR="$HOME/Library/Application Support/camunda-modeler/resources/element-templates"
if [ -d "$TEMPLATE_DIR" ]; then
    rm -rf "$TEMPLATE_DIR"
fi
mkdir -p "$TEMPLATE_DIR"
cp $SOURCE_DIR/*json "$TEMPLATE_DIR"
