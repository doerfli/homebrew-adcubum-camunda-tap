#!/bin/bash
SOURCE_DIR=`dirname "$0"`
PLUGIN_BASE_DIR="$HOME/Library/Application Support/camunda-modeler/plugins"
PLUGIN_DIR="$PLUGIN_BASE_DIR/bpmn-js-token-simulation-plugin"
if [ -d "$PLUGIN_DIR" ]; then
    rm -rf "$PLUGIN_DIR"
fi
mkdir -p "$PLUGIN_DIR"
cp -r $SOURCE_DIR/bpmn-js-token-simulation-plugin/* "$PLUGIN_DIR"
