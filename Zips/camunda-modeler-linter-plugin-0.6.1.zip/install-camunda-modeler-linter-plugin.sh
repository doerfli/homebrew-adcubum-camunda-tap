#!/bin/bash
SOURCE_DIR=`dirname "$0"`
PLUGIN_BASE_DIR="$HOME/Library/Application Support/camunda-modeler/plugins"
PLUGIN_DIR="$PLUGIN_BASE_DIR/camunda-modeler-linter-plugin"
if [ -d "$PLUGIN_DIR" ]; then
    rm -rf "$PLUGIN_DIR"
fi
mkdir -p "$PLUGIN_DIR"
cp -r $SOURCE_DIR/camunda-modeler-linter-plugin/* "$PLUGIN_DIR"
