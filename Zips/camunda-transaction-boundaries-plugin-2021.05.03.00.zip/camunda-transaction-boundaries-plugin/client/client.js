import {
  registerBpmnJSPlugin
} from 'camunda-modeler-plugin-helpers';

import module from './module';

registerBpmnJSPlugin(module);
