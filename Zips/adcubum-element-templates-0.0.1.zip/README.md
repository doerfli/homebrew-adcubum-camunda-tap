# Installation instructions

Do not forget to install this template for linux and windows users (and check if it is still working for mac).

Download the latest archive:
  https://git.adcubum.com/rest/api/latest/projects/SYR/repos/camunda-modeler-element-templates/archive?format=zip

